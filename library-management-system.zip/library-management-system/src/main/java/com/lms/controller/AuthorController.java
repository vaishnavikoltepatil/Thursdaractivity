package com.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.entity.Author;
import com.lms.model.AuthorDTO;
import com.lms.service.AuthorService;
import com.lms.util.AuthorConverter;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/author")
public class AuthorController {

	@Autowired
	private AuthorService authorService;
	
	@Autowired
	private AuthorConverter converter;
	
	@PostMapping("/createAuthor")
	public AuthorDTO createBook(@Valid @RequestBody AuthorDTO authorDTO)
	{
		Author author=converter.convertDTOToAuthor(authorDTO);
		return authorService.createAuthor(author);
	}
	
	@GetMapping("/getAuthorById/{id}")
	public AuthorDTO getAuthorById(@PathVariable("id") int id)
	{
		return authorService.getAuthorById(id);
	}
}
