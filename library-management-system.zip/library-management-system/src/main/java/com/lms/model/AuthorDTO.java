package com.lms.model;

import java.util.List;

import com.lms.entity.Book;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthorDTO {
	
	private int aId;
	@NotNull(message = "Author Name should not be null")
	private String authorName;
	
	private List<Book> books;
}
