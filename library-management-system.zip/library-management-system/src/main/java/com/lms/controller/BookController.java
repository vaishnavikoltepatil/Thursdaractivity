package com.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.entity.Book;
import com.lms.model.BookDTO;
import com.lms.service.BookService;
import com.lms.util.Converter;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/books")
public class BookController {

	@Autowired
	private BookService bookService;
	
	@Autowired
	private Converter converter;
	
	@PostMapping("/createBook")
	public String createBook(@Valid @RequestBody BookDTO bookDTO)
	{
		final Book book=converter.convertDTOToBook(bookDTO);
		return bookService.createBook(book);
	}
	
	@GetMapping("/getBookById/{id}")
	public BookDTO getBookById(@PathVariable("id") int id)
	{
		return bookService.getBookById(id);
	}
	
	@GetMapping("/getAllBooks")
	public List<BookDTO> getAllBooks(){
		return bookService.getAllBooks();
	}
	
	@PutMapping("/updateBook/{id}")
	public BookDTO updateBook(@PathVariable("id") int id, 
			@Valid @RequestBody BookDTO bookDTO)
	{
		Book book1 =converter.convertDTOToBook(bookDTO);
		return bookService.updateBook(id, book1);
	}
	
	@DeleteMapping("/deleteById/{id}")
	public String deleteBookById(@PathVariable("id") int id)
	{
		return bookService.deleteBookById(id);
	}
	
	@DeleteMapping("/deleteAllBooks")
	public ResponseEntity<String> deleteAllBooks()
	{
		bookService.deleteAllBooks();
		return new ResponseEntity<String>("All book details got deleted!", 
				HttpStatus.OK);
	}
	
	@GetMapping("/getBookByName/{name}")
	public List<BookDTO> getBookByName(@PathVariable("name") String bookName)
	{
		return bookService.getBookByName(bookName);
	}
	
	@GetMapping("/getBookByPublisher/{name}")
	public List<BookDTO> getBookByPublication(@PathVariable("name") String publication)
	{
		return bookService.findByPublication(publication);
	}
	
	@PostMapping("/assignBookToAuthor/{bookid}/{authorid}")
	public BookDTO assignBookToAuthor(@PathVariable("bookid") int bookId, 
			@PathVariable("authorid") int authorId)
	{
		return bookService.assignBookToAuthor(bookId, authorId);
	}
}
