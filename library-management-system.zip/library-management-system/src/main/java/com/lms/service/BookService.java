package com.lms.service;

import java.util.List;

import com.lms.entity.Book;
import com.lms.model.BookDTO;

public interface BookService {

	String createBook(Book book); //save a new book
	BookDTO getBookById(int id); //fetch data of a book using the id
	List<BookDTO> getAllBooks(); //fetch all books
	BookDTO updateBook(int id, Book book); //fetch and update the book details
	String deleteBookById(int id); //deleting a book using id
	void deleteAllBooks(); //delete all the books
	List<BookDTO> getBookByName(String bookName);
	List<BookDTO> findByPublication(String publication);
	BookDTO assignBookToAuthor(int bookId, int authorId);
}
