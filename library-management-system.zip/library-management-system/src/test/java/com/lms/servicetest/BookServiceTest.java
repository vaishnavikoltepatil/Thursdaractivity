package com.lms.servicetest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.lms.entity.Book;
import com.lms.model.BookDTO;
import com.lms.repository.BookRepository;
import com.lms.service.BookService;
import com.lms.util.Converter;

@SpringBootTest
public class BookServiceTest {

	@Autowired
	private BookService bookService;
	
	@Autowired
	private Converter converter;
	
	@MockBean
	private BookRepository bookRepository;
	
	@Test
	void testCreateBook()
	{
		Book book = Book.builder().bookName("Cloud Comp.").bookPrice(350.0).
				publication("Nirali").build();
		
		Mockito.when(bookRepository.save(book)).thenReturn(book);
		//assertEquals("Book details added successfully!!", bookService.createBook(book));
		assertThat(bookService.createBook(book)).isEqualTo("Book details added successfully!!");
	}
	
	@Test
	void testGetBookById()
	{
		Book book1 = Book.builder().id(2).bookName("Cloud Comp.").bookPrice(350.0).
				publication("Nirali").build();
		
		Mockito.when(bookRepository.save(book1)).thenReturn(book1);
		assertEquals("Cloud Comp.",book1.getBookName());
	}
	
	@Test
	void testGetAllBooks()
	{
		Book book = Book.builder().bookName("AI").bookPrice(900.0).
				publication("Nirali").build();
		Book book1 = Book.builder().bookName("Cloud Comp.").bookPrice(350.0).
				publication("Nirali").build();
		
		List<Book> list = new ArrayList<>();
		list.add(book1);
		list.add(book);
		
		Mockito.when(bookRepository.findAll()).thenReturn(list);
		
		List<BookDTO> dto = bookService.getAllBooks();
		
		List<Book> books = new ArrayList<Book>();
		dto.forEach(bookDto->
		books.add(converter.convertDTOToBook(bookDto))
				);
		
		assertThat(books.get(0).getBookName()).isEqualTo(list.get(0).getBookName());
	}
	
	@Test
	void testUpdateBook()
	{
		Book book = Book.builder().bookName("Cloud Comp.").bookPrice(350.0).
				publication("Nirali").build();
		
		Optional<Book> opBook = Optional.of(book);
		
		Mockito.when(bookRepository.findById(book.getId())).thenReturn(opBook);
		
		Book b = opBook.get();
		book.setBookName("AI");
		
		Mockito.when(bookRepository.save(book)).thenReturn(b);
		
		BookDTO dto=bookService.updateBook(book.getId(), book);
		assertEquals(dto.getBookName(), b.getBookName());
		
		
		
	}
	
	
	
	
	
	
	
}
