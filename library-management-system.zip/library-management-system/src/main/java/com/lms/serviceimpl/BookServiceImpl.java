package com.lms.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.entity.Author;
import com.lms.entity.Book;
import com.lms.exception.ResourceNotFoundException;
import com.lms.model.BookDTO;
import com.lms.repository.AuthorRepository;
import com.lms.repository.BookRepository;
import com.lms.service.BookService;
import com.lms.util.Converter;

@Service
public class BookServiceImpl implements BookService{

	private static final Logger log = LoggerFactory.getLogger(Book.class);
	
	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private AuthorRepository authorRepository;
	
	@Autowired
	private Converter converter;
	
	@Override
	public String createBook(Book book) {
		String message=null;
		
		book.setBookName(book.getBookName());
		book.setBookPrice(book.getBookPrice());
		book.setPublication(book.getPublication());
		
		bookRepository.save(book);
		log.info("Creating a new book "+book.toString()+" added at "+new Date());
		if(book!=null)
		{
			message = "Book details added successfully!!";
		}
		return message;
	}

	@Override
	public BookDTO getBookById(int id) {
		Book book =bookRepository.findById(id).orElseThrow(()-> 
		new ResourceNotFoundException("Book", "ID", id));
		log.info("Fetching book details with id "+id);
		return converter.convertEntityToBookDTO(book);
	}

	@Override
	public List<BookDTO> getAllBooks() {
		List<Book> books=bookRepository.findAll();
		List<BookDTO> booksDTO = new ArrayList<>();
		for(Book b: books)
		{
			booksDTO.add(converter.convertEntityToBookDTO(b));
		}
		log.info("Fetching all books at "+new Date());
		return booksDTO;
	}

	@Override
	public BookDTO updateBook(int id, Book book) {
		Book existingBook=bookRepository.findById(id).get();
		
		existingBook.setBookName(book.getBookName());
		existingBook.setBookPrice(book.getBookPrice());
		existingBook.setPublication(book.getPublication());
		
		bookRepository.save(existingBook);
		log.info("Updating book details of id "+id+" at "+new Date());
		return converter.convertEntityToBookDTO(existingBook);
	}

	@Override
	public String deleteBookById(int id) throws ResourceNotFoundException{
		String msg=null;
		Optional<Book> book=bookRepository.findById(id);
		if(book.isPresent())
		{
			bookRepository.deleteById(id);
			log.info("Deleting a book");
			msg= "Book deleted successfully!!";
		}
		else
		{
			log.error("Book with id "+id+" was not found!");
			throw new ResourceNotFoundException("Book", "Id", id);
		}
		return msg;
	}

	@Override
	public void deleteAllBooks() {
		bookRepository.deleteAll();
		
	}

	@Override
	public List<BookDTO> getBookByName(String bookName) {
		List<Book> book=bookRepository.findByBookName(bookName);
		List<BookDTO> booksDTO = new ArrayList<>();
		for(Book b: book)
		{
			booksDTO.add(converter.convertEntityToBookDTO(b));
		}
		return booksDTO;
	}

	@Override
	public List<BookDTO> findByPublication(String publication) {
		List<Book> book1=bookRepository.findByPublication(publication);
		List<BookDTO> booksDTO = new ArrayList<>();
		for(Book b: book1)
		{
			booksDTO.add(converter.convertEntityToBookDTO(b));
		}
		return booksDTO;
	}

	@Override
	public BookDTO assignBookToAuthor(int bookId, int authorId) {
		Book book = bookRepository.findById(bookId).get();
		Author author = authorRepository.findById(authorId).get();
		
		book.setAuthor(author);
		Book b = bookRepository.save(book);
		
		return converter.convertEntityToBookDTO(b);
	}

}
