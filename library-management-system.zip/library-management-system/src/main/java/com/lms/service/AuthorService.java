package com.lms.service;

import com.lms.entity.Author;
import com.lms.model.AuthorDTO;


public interface AuthorService {

	AuthorDTO createAuthor(Author author);
	AuthorDTO getAuthorById(int id);
}
