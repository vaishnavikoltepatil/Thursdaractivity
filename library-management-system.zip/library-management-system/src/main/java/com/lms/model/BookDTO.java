package com.lms.model;


import com.lms.entity.Author;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookDTO {

	private int id;
	@NotNull(message = "Book Name should not be null")
	private String bookName;
	@NotNull(message = "Book Price should not be null")
	private double bookPrice;
	@NotNull(message = "Publication should not be null")
	private String publication;
	
	private Author author;
}
