package com.lms.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.lms.entity.Book;
import com.lms.model.BookDTO;

@Component
public class Converter {

	//converts from Book entity to BookDTO
	public BookDTO convertEntityToBookDTO(Book book)
	{
		BookDTO bookDTO = new BookDTO();
		if(book!=null)
		{
			BeanUtils.copyProperties(book, bookDTO);
		}
		return bookDTO;
	}
	
	//converts from BookDTO to Book entity
	public Book convertDTOToBook(BookDTO bookDTO)
	{
		Book book = new Book();
		if(bookDTO!=null)
		{
			BeanUtils.copyProperties(bookDTO, book);
		}
		return book;
	}
}
