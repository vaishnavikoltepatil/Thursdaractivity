package com.lms.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.lms.entity.Author;
import com.lms.model.AuthorDTO;



@Component
public class AuthorConverter {

	public AuthorDTO convertEntityToAuthorDTO(Author author)
	{
		AuthorDTO authorDTO = new AuthorDTO();
		if(author!=null)
		{
			BeanUtils.copyProperties(author, authorDTO);
		}
		return authorDTO;
	}
	
	//converts from BookDTO to Book entity
	public Author convertDTOToAuthor(AuthorDTO authorDTO)
	{
		Author author = new Author();
		if(authorDTO!=null)
		{
			BeanUtils.copyProperties(authorDTO, author);
		}
		return author;
	}
}
