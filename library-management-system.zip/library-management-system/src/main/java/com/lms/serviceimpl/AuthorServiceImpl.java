package com.lms.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.entity.Author;
import com.lms.exception.ResourceNotFoundException;
import com.lms.model.AuthorDTO;
import com.lms.repository.AuthorRepository;
import com.lms.service.AuthorService;
import com.lms.util.AuthorConverter;

@Service
public class AuthorServiceImpl implements AuthorService{

	@Autowired
	private AuthorRepository authorRepository;
	
	@Autowired
	private AuthorConverter converter;
	
	@Override
	public AuthorDTO createAuthor(Author author) {
		Author auth=authorRepository.save(author);
		return converter.convertEntityToAuthorDTO(auth);
	}

	@Override
	public AuthorDTO getAuthorById(int id) {
		
		Author author =authorRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Author", "ID", id));
		
		return converter.convertEntityToAuthorDTO(author);
	}

}
